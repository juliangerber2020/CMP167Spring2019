/* 
 * File: Quadratic.java
 * Author: Julian Gerber
 * Created: 2/14/19
 * Description: This program implements the quadratic formula.
 */  

import java.util.Scanner;
public class Quadratics {
	
	public static void main(String[] args) {
		double Root1, Root2;
		double a, b, c;
		
		Scanner scnr = new Scanner(System.in);
		System.out.println("Enter value of a: ");
		a = scnr.nextDouble();
		System.out.println("Enter value of b: ");
		b = scnr.nextDouble();
		System.out.println("Enter value of c: ");
		c = scnr.nextDouble();
		
		double Discriminant = (Math.pow(b,  2)) - (4 * a * c);
		Root1 = ((-b) + Math.sqrt(Discriminant)) / (2 * a);
		Root2 = ((-b) - Math.sqrt(Discriminant)) / (2 * a);
		
		System.out.println("Root 1 = " + Root1);
		System.out.println("Root 2 = " + Root2);
	}

}
